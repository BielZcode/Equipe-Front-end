package net.ftclient.clientcommon.Manager;

public class Account {
    private String username;

    // Getter e Setter
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
